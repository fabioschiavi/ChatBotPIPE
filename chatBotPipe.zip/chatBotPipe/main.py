import tkinter as tk
from chatbot import ChatBot

# Função para enviar a pergunta do usuário e obter a resposta do chatbot
def enviar_pergunta():
    pergunta = entrada_pergunta.get()
    resposta, intencao = myChatBot.chatbot_response(pergunta)
    texto_resposta.config(state=tk.NORMAL)
    texto_resposta.insert(tk.END, f"\nUsuário: {pergunta}\nChatBot: {resposta}\n")
    texto_resposta.config(state=tk.DISABLED)
    if intencao[0]['intent'] == "despedida":
        texto_resposta.insert(tk.END, "\nFoi um prazer atendê-lo, para mais informações você também pode acessar o site: https://fapesp.br/pipe/\n")

# Criação do ChatBot
myChatBot = ChatBot()
myChatBot.createModel()

# Configuração da janela
janela = tk.Tk()
janela.title("Chatbot do PIPE")

# Criação dos widgets
tk.Label(janela, text="Bem vindo ao Chatbot do PIPE\n Qualquer dúvida digite menu").pack()
entrada_pergunta = tk.Entry(janela, width=50)
entrada_pergunta.pack()
botao_enviar = tk.Button(janela, text="Enviar", command=enviar_pergunta)
botao_enviar.pack()
texto_resposta = tk.Text(janela, wrap=tk.WORD, width=60, height=20)
texto_resposta.config(state=tk.DISABLED)
texto_resposta.pack()

# Execução da janela
janela.mainloop()
